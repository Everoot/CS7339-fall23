# README 

I write the whole code in `Main.java` file, you can run the code in the following steps.

1. `javac *.java`

2. `java *.java`

![Screenshot 2023-09-29 at 22.20.09](./README.assets/Screenshot 2023-09-29 at 22.20.09.png)

It will also generate `output.txt` to store the result.

![Screenshot 2023-09-29 at 22.51.50](./README.assets/Screenshot 2023-09-29 at 22.51.50.png)